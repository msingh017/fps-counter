package com.example.fpscounter;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class MyService extends Service {
    private Handler mhd;
    private TextView t;
    private Runnable mtr;
    private WindowManager wm;
    private View topLeftView;

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        t=new TextView(this);
        t.setAlpha(0.0f);
        t.setBackgroundColor(Color.BLACK);
         topLeftView = new View(this);

        WindowManager.LayoutParams topLeftParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,   WindowManager.LayoutParams.TYPE_SYSTEM_ALERT, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        topLeftParams.gravity = Gravity.LEFT | Gravity.TOP;
        topLeftParams.x = 0;
        topLeftParams.y = 0;
        topLeftParams.width = 0;
        topLeftParams.height = 0;
        wm.addView(topLeftView, topLeftParams);
        mhd=new Handler();
        mtr=new Runnable() {
            @Override
            public void run() {
                ProcessBuilder cmd;
                String result = "";
                try {
                    String[] args = { "/system/bin/cat", "/sys/class/drm/sde-crtc-0/measured_fps" };
                    cmd = new ProcessBuilder(args);
                    Process process = cmd.start();
                    InputStream in = process.getInputStream();
                    byte[] re = new byte[32768];
                    int read = 0;
                    read = in.read(re, 0, 32768);
                    if( read != -1) {
                        String string = new String(re, 0, read);
                        t.setText(string);
                        Log.e("Rah", string);

                    }
                    in.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                mhd.postDelayed(this,1000);

            }
        };

        mtr.run();

    }
}