package com.example.fpscounter;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
   /* private Handler mhd;
    TextView t;
    private Runnable mtr;*/




    public static int OVERLAY_PERMISSION_REQ_CODE = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*t=(TextView)findViewById(R.id.txt);
        mhd=new Handler();
        mtr=new Runnable() {
            @Override
            public void run() {
                ProcessBuilder cmd;
                String result = "";
                try {
                    String[] args = { "/system/bin/cat", "/sys/class/drm/sde-crtc-0/measured_fps" };
                    cmd = new ProcessBuilder(args);
                    Process process = cmd.start();
                    InputStream in = process.getInputStream();
                    byte[] re = new byte[32768];
                    int read = 0;
                    read = in.read(re, 0, 32768);
                    if( read != -1) {
                        String string = new String(re, 0, read);
                        t.setText(string);
                        Log.e("Rah", string);

                    }
                    in.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                mhd.postDelayed(this,1000);

            }
        };

            mtr.run();*/
    }

    public void start(View v){
        Intent svc = new Intent(this, MyService.class);
       // startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))

        startService(svc);
        finish();
    }


  /*  private Runnable mtr=new Runnable() {
        @Override
        public void run() {
            ProcessBuilder cmd;
            String result = "";
            try {
                String[] args = { "/system/bin/cat", "/sys/class/drm/sde-crtc-0/measured_fps" };
                cmd = new ProcessBuilder(args);
                Process process = cmd.start();
                InputStream in = process.getInputStream();
                byte[] re = new byte[32768];
                int read = 0;
                read = in.read(re, 0, 32768);
                if( read != -1) {
                    String string = new String(re, 0, read);
                    t.setText(string);
                    Log.e("Rah", string);

                }
                in.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            mhd.postDelayed(this,1000);

        }
    };
    public void fun(View v) {
     mtr.run();
    }*/

}
